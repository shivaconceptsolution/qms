

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 * Servlet implementation class RegSer
 */
@WebServlet("/RegSer")
public class RegSer extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		Transaction tx = s.beginTransaction();
		Reg obj = new Reg();
		obj.setUsername(request.getParameter("txtuser"));
		obj.setPassword(request.getParameter("txtpass"));
		obj.setEmail(request.getParameter("txtemail"));
		obj.setMobile(request.getParameter("txtmobile"));
		s.save(obj);
		tx.commit();
		s.close();
		response.sendRedirect("index.jsp?q=Regisstration successfully");
		
		
		
		
		
		
	}

}
