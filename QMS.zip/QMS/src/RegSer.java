

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import dal.Reg;
import helper.Datahelper;

/**
 * Servlet implementation class RegSer
 */
@WebServlet("/RegSer")
public class RegSer extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Datahelper.connection();
		Reg obj = new Reg();
		obj.setUsername(request.getParameter("txtuser"));
		obj.setPassword(request.getParameter("txtpass"));
		obj.setEmail(request.getParameter("txtemail"));
		obj.setMobile(request.getParameter("txtmobile"));
		Datahelper.insertOperation(obj);
		Datahelper.closeConnection();
		response.sendRedirect("index.jsp?q=Regisstration successfully");
		
		
		
		
		
		
	}

}
