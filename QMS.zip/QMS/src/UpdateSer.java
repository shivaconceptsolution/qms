

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import dal.Reg;
import helper.Datahelper;

/**
 * Servlet implementation class UpdateSer
 */
@WebServlet("/UpdateSer")
public class UpdateSer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public UpdateSer() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Datahelper.connection();
		Object o = Datahelper.findOperation(Reg.class,request.getParameter("txtuser"));
		Reg obj = (Reg)o;
		obj.setPassword(request.getParameter("txtpass"));
		obj.setEmail(request.getParameter("txtemail"));
		obj.setMobile(request.getParameter("txtmobile"));
	    Datahelper.updateOperation(obj);
		response.sendRedirect("viewreg.jsp");
	}

}
