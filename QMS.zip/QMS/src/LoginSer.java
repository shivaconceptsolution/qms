

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import dal.Reg;
import helper.Datahelper;
/**
 * Servlet implementation class LoginSer
 */
@WebServlet("/LoginSer")
public class LoginSer extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Datahelper.connection();
 	    Query q = Datahelper.selectWithParam("from Reg s where s.username=? and s.password=?");
 	    q.setString(0,request.getParameter("txtuser"));
 	    q.setString(1,request.getParameter("txtpass"));
 	    List lst = q.list();
 	    if(lst.size()>0)
 	    {
 	    	response.sendRedirect("viewreg.jsp");
 	    }
 	    else
 	    {
 	    	response.sendRedirect("login.jsp?q=invalid userid and password");
 	    }
 	    
 	 }

}
