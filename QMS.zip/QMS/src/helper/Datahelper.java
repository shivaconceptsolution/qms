package helper;



import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Datahelper {
  static Configuration cfg;
  static SessionFactory sf;
  static Session s;
  static Transaction tx;
  public static void connection()
  {
	   cfg = new Configuration();
	   cfg.configure("hibernate.cfg.xml");
	   sf = cfg.buildSessionFactory();
	   s = sf.openSession();
  }
  
  public static void insertOperation(Object o)
  {
	  
	    s.save(o);
		tx.commit();
		
  }
  public static Object findOperation(Class c,String id)
  {
	  return s.get(c, id);
	  
  }
  public static void updateOperation(Object o)
  {
	    s.save(o);
		tx.commit();
  }
  public static void deleteOperation(Object o)
  {
	    s.delete(o);
		tx.commit();
  }
  public static List selectOperation(String query)
  {
	  Query q = s.createQuery(query);
	  return q.list();
	  
  }
  public static Query selectWithParam(String query)
  {
	  return s.createQuery(query);
  }
  public static void closeConnection()
  {
	  s.close();
	  sf.close();
  }
	
}
